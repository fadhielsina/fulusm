<div class="row border-responsive">
          <div class="col-md-12 col-lg-7 mb-4 mb-lg-0 border-right">
	
            <div class="text-left" style="margin:6%;">
            <h3 style="color:#ff8f3d">Fulusme </h3>
						
						<br />
					

						<p align="left" style="color:#5fa5b1; font-size: 17px;
}"><b>Visi</b></p>
						<p align="justify">Menjadi Perusahaan Teknologi Finansial terkemuka di Regional Asia Tenggara yang berkepribadian Indonesia</p>
						<p align="left" style="color:#5fa5b1; font-size: 17px;
}"><b>Misi</b></p>
						<p align="justify">Memajukan percepatan ekonomi Indonesia dengan menggunakan teknologi yang tetap berprinsip kepada nilai keadilan dan manusiawi
						Membangun peradaban digital di wilayah regional dengan membawa nilai Indonesia</p>
                        <br>
                        
                        <h3 style="color:#ff8f3d">Apakah Sekurities Crowd Funding (SCF) ?</h3>
<b></b></p>
						<p align="justify">Adalah layanan urun dana yang menawarkan efek dan surat hutang berbasis informasi teknologi.</p>
<b></b></p>
						<p align="justify">SCF mempertemukan Pemodal yang memiliki dana dan Penerbit, sebuah perusahaan yang membutuhkan dana.</p>
<b></b></p>
						<p align="justify">SCF merupakan alternatif investasi jangka panjang yang menguntungkan.</p>
<b></b></p>
						<p align="justify">SCF merupakan langkah mudah bagi Pemodal untuk memiliki bisnis dengan cara cepat dan di jalankan oleh praktisi yang berpengalaman di bidangnya, tanpa harus repot membangun bisnis baru.</p>
<b></b></p>
						<p align="justify">Demikian pula untuk Penerbit yang membutuhkan permodalan, dapat segera membiayai bisnisnya dalam waktu singkat.</p>
						
				
                        <p align="center" style="color:#5fa5b1;font-size: 17px;
}"><b></b></p>
            </div>
          </div>
          <div class="col-md-12 col-lg-5 mb-4 mb-lg-0 border-right">
            <div class="text-center">
              <img src="<?php echo base_url(); ?>assetsprofile/assetsbaru/images/hero_bg_1.jpg" width="100%" style="margin-top:6%;margin-bottom:6%;">
            </div>
          </div>
        </div>