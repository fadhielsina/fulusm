

    <title>.:: Dealfintech ::.</title>
	<link rel="icon" type="image/ico" href="pic/icon.ico" />
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
	<script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


  
<!-- Mirrored from dealfintech.com/firi.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 27 Mar 2019 10:25:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<body>
      
    <section class="breadcrumb">
	<div class="container">
			<div class="row">
			<div class="col-sm-12">
				<h4>Registrasi Pemodal</h4>
				<li>
				<a href="index.html"><i class="entypo-home"></i>Kembali</a>
			    </li>
			</div>
		</div>
	</div>
</section>
      
	<div class="row justify-content-center">
																			<div class="col-md-6">
																			<div class="card">
																			<header class="card-header">
																				<h4 class="card-title mt-2">Daftar Sebagai Pemodal</h4>
																			</header>
																			<article class="card-body">
																			<form  action="http://dealfintech.com/psri.php" method="post"> 
																				<div class="form-group">
																					<label>Jenis Pemodalan : </label> 
																						<label class="form-check form-check-inline">
																					  <input class="form-check-input" type="radio" name="Jenis" id="Jenis"  value="1">
																					  <span class="form-check-label"> Individu </span>
																					</label>
																					<label class="form-check form-check-inline">
																					  <input class="form-check-input" type="radio" name="Jenis" id="Jenis" value="0">
																					  <span class="form-check-label"> Badan Hukum</span>
																					</label>
																				</div> <!-- form-group end.// --> 
																				<div class="form-row">
																					<div class="col form-group">
																						<label>Nama Lengkap :</label>   
																						<input type="text" class="form-control" name="nama" id="nama" value="">
																					</div> <!-- form-group end.// -->
																				</div> <!-- form-row end.// -->
																				<div class="form-row">
																					<div class="col form-group">
																						<label>No. KTP / Passpor :</label>   
																						<input type="text" class="form-control" name="noktp" id="noktp" value="">
																					</div> <!-- form-group end.// -->
																				</div> <!-- form-row end.// -->
																				<div class="form-row">
																					<div class="col form-group">
																						<label>No. NPWP :</label>   
																						<input type="text" class="form-control" name="nonpwp" id="nonpwp" value="">
																					</div> <!-- form-group end.// -->
																				</div> <!-- form-row end.// -->
																				<div class="form-group">
																					<label>Kewarganegaraan : </label> 
																						<label class="form-check form-check-inline">
																					  <input class="form-check-input" type="radio" name="wn" value="1">
																					  <span class="form-check-label"> WNI </span>
																					</label>
																					<label class="form-check form-check-inline">
																					  <input class="form-check-input" type="radio" name="wn" value="0">
																					  <span class="form-check-label"> WNA</span>
																					</label>
																				</div> <!-- form-group end.// --> 
																				<div class="form-row">
																					<div class="col form-group">
																						<label>No. Handphone :</label>   
																						<input type="text" class="form-control" name="nohp" id="nohp" value="">
																					</div> <!-- form-group end.// -->
																				</div> <!-- form-row end.// -->
																				<div class="form-group">
																					<label>Email :</label>
																					<input type="email" class="form-control" id="useremail" name="useremail">
																				</div> <!-- form-group end.// -->
																				
																				<div class="form-group">
																					<button type="submit" class="btn btn-primary btn-block"> Daftar  </button>
																				</div> <!-- form-group// -->       
																			</form>
																			</article> <!-- card-body end .// -->
																			<div class="border-top card-body text-center">Sudah Menjadi Member? <a href="login.html">Masuk</a></div>
																			</div> <!-- card.// -->
																			</div> <!-- col.//-->
								<!-- /. end container -->

    <!-- Footer -->


    <!-- Bootstrap core JavaScript -->
   

  </body>

