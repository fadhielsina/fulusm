<?php
// var_dump($project_retail);


function rupiah($angka){
	
	$hasil_rupiah = "Rp " . number_format($angka,0,',','.');
	return $hasil_rupiah;
 
};
// echo time();
// var_dump(count($project));
// exit;

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-35VN14CNFE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-35VN14CNFE');
</script>
 ?>

					<div class="kt-body kt-grid kt-grid--hor kt-grid--stretch" id="kt_body" style="background: #e5f3ff;">
						<div class="kt-grid kt-grid--hor" id="kt_content">



















        <div id="carouselExampleControlss" 
             class="carousel slide" 
             data-ride="carousel">
			<div class="carousel-inner" style="color:white">
				<div class="carousel-item active" >
									<!-- begin:: Content -->
<!--							<div >-->

								<!-- begin:: Hero -->
<!--								<div class="kt-portlet kt-sc-2" style="-->
<!--    background-image: url(https://www.fintekmadani.id/assetsprofile/asset/images/smart-4168483.jpg);-->
<!--    color: black;-->
<!--    background-position: center;-->
<!--    background-repeat: no-repeat;-->
<!--    background-size: cover;-->
<!--">-->
<!--									<div class="kt-portlet__body" style="height: 80vh;">-->
										
<!--										<div class="kt-sc__bg" style="-->
<!--    height: 90%; -->
<!--">-->
<!--											<img style="-->
<!--											width: 40%;-->
<!--											margin-top: 50px;-->
											
<!--											" src="<?= base_url('assetsprofile/')?>asset/images/image_open.png">	-->
										
<!--										</div>-->
<!--										<div class="kt-sc__top">-->
<!--											<div class="kt-sc__content">-->
<!--												<h1 class="kt-sc__title" style="color: #fff;    font-size: 10vh; margin-bottom: 5px;">-->
<!--													Fulusme Sekuritas <br>-->
<!--												</h1>-->
<!--												<h2 style="margin-top: 0px; color:white;">Layanan Urun Dana berbasis Teknologi </h2>-->

							<!--					<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">-->
							<!--						<div class="carousel-inner" style="color:white">-->
							<!--						  <div class="carousel-item active" >-->
							<!--							<p style="-->
							<!--margin-top: 36px;-->
							<!--font-size: 15px;-->
							<!--font-weight: 200;-->
							<!--margin-bottom: 50px;-->
							<!--">Hi, selamat datang di jaman now, dimana kecepatan dan instant sudah menjadi bagian dari keseharian kita, dimana Pemodal dan penerbit tidak lagi dibatasi oleh ruang dan waktu</p>-->
							<!--						  </div>-->
							<!--						  <div class="carousel-item">-->
							<!--							<p style="-->
							<!--margin-top: 36px;-->
							<!--font-size: 15px;-->
							<!--font-weight: 200;-->
							<!--margin-bottom: 50px;-->
							<!--">Kami senantiasa mendukung pendanaan dan bisnis anda melalui teknologi Securities Crowd Funding terkini dan beradaptasi selalu dari waktu ke waktu.</p>-->
							<!--						  </div>-->
							<!--						  <div class="carousel-item">-->
							<!--							<p style="-->
							<!--margin-top: 36px;-->
							<!--font-size: 15px;-->
							<!--font-weight: 200;-->
							<!--margin-bottom: 50px;-->
							<!--">Fulusme Sekuritas adalah Layanan Urun Dana Berbasis Teknologi (Securities Crowd Funding), yang kami bangun untuk dapat bermanfaat bagi dunia bisnis di Indonesia.</p>-->
							<!--						  </div>-->
							<!--						</div>-->
							<!--						<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">-->
							<!--						  <span class="carousel-control-prev-icon" aria-hidden="true"></span>-->
							<!--						  <span class="sr-only">Previous</span>-->
							<!--						</a>-->
							<!--						<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">-->
							<!--						  <span class="carousel-control-next-icon" aria-hidden="true"></span>-->
							<!--						  <span class="sr-only">Next</span>-->
							<!--						</a>-->
							<!--					  </div>-->
												
<!--											</div>-->
<!--										</div>-->
<!--									</div>-->
									
<!--								</div>-->


								<!-- end:: Hero -->

							
<!--							</div>-->


            	<img src="<?= base_url('assetsprofile/')?>asset/images/baru01.jpg" alt="Los Angeles" style="width:100%; height: 70vh;object-fit: fill;margin-bottom:20px; margin-left:15px; margin-right:-15px; margin-top:1vh;">		
						
				</div>
				<div class="carousel-item">
												<img src="<?= base_url('assetsprofile/')?>asset/images/barusaja1.jpg" alt="Los Angeles" style="width:100%; height: 70vh;margin-bottom:20px;">		
				</div>
				<div class="carousel-item">
														<img src="<?= base_url('assetsprofile/')?>asset/images/kedai kopi.jpg" alt="Los Angeles" style="width:100%; height: 70vh;margin-bottom:20px;">		
				</div>
				<div class="carousel-item">
														<img src="<?= base_url('assetsprofile/')?>asset/images/pet (2).jpg" alt="Los Angeles" style="width:100%; height: 70vh;margin-bottom:20px;">		
				</div>
				 <!--object-fit: cover; -->
		    </div>
			<a class="carousel-control-prev" href="#carouselExampleControlss" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" 
				aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleControlss" role="button" data-slide="next">
				<span class="carousel-control-next-icon" 
				aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  
												  




						





















							<h2 class="text-center mt-2">Apa itu Fulusme sekuritas ? </h2>
							<div style="padding-left: 25%; padding-right: 25%; margin-top: 0; margin-bottom: 0;" class="kt-container ">
								<div class="row">
									<div class="col-lg-4" style="padding:20px;">
										<a href="#" class="kt-portlet kt-iconbox kt-iconbox--success" >
											<div class="kt-portlet__body" style="margin: auto; padding:0;
                                      
											">
												<div class="kt-iconbox__body">
													
													<div class="kt-iconbox__desc kt-iconbox__icon" data-toggle="kt-popover" title="" 
													data-content="wadah tempat bertemunya pemodal dan penerbit yang dihubungkan dengan teknologi aplikasi.." 
													style="flex: unset;
													padding-right: unset;">
														<svg style="height:100px; width:100%;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
															<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																<rect x="0" y="0" width="24" height="24"/>
																<path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z" fill="#000000" opacity="0.3" transform="translate(11.500000, 12.000000) rotate(-345.000000) translate(-11.500000, -12.000000) "/>
																<path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z M11.5,14 C12.6045695,14 13.5,13.1045695 13.5,12 C13.5,10.8954305 12.6045695,10 11.5,10 C10.3954305,10 9.5,10.8954305 9.5,12 C9.5,13.1045695 10.3954305,14 11.5,14 Z" fill="#000000"/>
																<rect fill="#000000" opacity="0.2" x="4" y="21" width="16" height="2" rx="1"/>
															</g>
														</svg>

														<h3 class="kt-iconbox__title text-center" style="
    font-size: 15px;
">
															Layanan Urun Dana Berbasis Teknologi
														</h3>
													
													</div>
												</div>
											</div>
										</a>
									</div>
									<div class="col-lg-4" style="padding:20px;">
										<a href="#" class="kt-portlet kt-iconbox  kt-iconbox--warning" style="border-radius:300px;" >
											<div class="kt-portlet__body" style="margin: auto; padding:0;
                                      
											">
												<div class="kt-iconbox__body">
													
													<div class="kt-iconbox__desc kt-iconbox__icon" data-toggle="kt-popover" title="" 
													data-content="Semua prosesnya transparan dan terbuka diawal, no penalty, Halal, Lebih menguntungkan semua pihak" 
													style="flex: unset;
													padding-right: unset;">
														<svg style="height:100px; width:100%;"xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
															<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																<rect x="0" y="0" width="24" height="24"/>
																<path d="M5,8.6862915 L5,5 L8.6862915,5 L11.5857864,2.10050506 L14.4852814,5 L19,5 L19,9.51471863 L21.4852814,12 L19,14.4852814 L19,19 L14.4852814,19 L11.5857864,21.8994949 L8.6862915,19 L5,19 L5,15.3137085 L1.6862915,12 L5,8.6862915 Z M12,15 C13.6568542,15 15,13.6568542 15,12 C15,10.3431458 13.6568542,9 12,9 C10.3431458,9 9,10.3431458 9,12 C9,13.6568542 10.3431458,15 12,15 Z" fill="#000000"/>
																<rect fill="#000000" opacity="0.2" x="4" y="21" width="16" height="2" rx="1"/>
															</g>
														</svg>

														<h3 class="kt-iconbox__title text-center" style="
    font-size: 15px;
">
															Securities Crowd Funding
														</h3>
														
													</div>
												</div>
											</div>
										</a>
									</div>
									<div class="col-lg-4" style="padding:20px;">
										<div class="kt-portlet kt-iconbox kt-iconbox--danger ">
											<div class="kt-portlet__body" style="margin: auto; padding:0;
                                      
											">
												<div class="kt-iconbox__body">
													
													<div class="kt-iconbox__desc kt-iconbox__icon" data-toggle="kt-popover" title="" 
													data-content="Kami, selalu ada dan siap mendampingi anda 24 jam sehari, 7 kali seminggu dan 365 hari non-stop melalui web kami.
													" 
													style="flex: unset;
													padding-right: unset;">
														<svg style="height:100px; width:100%;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
															<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																<rect x="0" y="0" width="24" height="24"/>
																<path d="M7.14296018,11.6653622 C7.06267828,11.7456441 6.95746388,11.7962128 6.84462255,11.8087507 C6.57016914,11.8392455 6.32295974,11.641478 6.29246492,11.3670246 L5.76926113,6.65819047 C5.76518362,6.62149288 5.76518362,6.58445654 5.76926113,6.54775895 C5.79975595,6.27330553 6.04696535,6.07553802 6.32141876,6.10603284 L11.0302529,6.62923663 C11.1430942,6.64177456 11.2483086,6.69234321 11.3285905,6.77262511 C11.5238526,6.96788726 11.5238526,7.28446974 11.3285905,7.47973189 L9.94288211,8.86544026 L11.4443443,10.3669024 C11.6396064,10.5621646 11.6396064,10.8787471 11.4443443,11.0740092 L10.7372375,11.781116 C10.5419754,11.9763782 10.2253929,11.9763782 10.0301307,11.781116 L8.52866855,10.2796538 L7.14296018,11.6653622 Z" fill="#000000" fill-rule="nonzero" opacity="0.3"/>
																<path d="M12.0799676,14.7839934 L14.2839934,12.5799676 C14.8927139,11.9712471 15.0436229,11.0413042 14.6586342,10.2713269 L14.5337539,10.0215663 C14.1487653,9.25158901 14.2996742,8.3216461 14.9083948,7.71292558 L17.6411989,4.98012149 C17.836461,4.78485934 18.1530435,4.78485934 18.3483056,4.98012149 C18.3863063,5.01812215 18.4179321,5.06200062 18.4419658,5.11006808 L19.5459415,7.31801948 C20.3904962,9.0071287 20.0594452,11.0471565 18.7240871,12.3825146 L12.7252616,18.3813401 C11.2717221,19.8348796 9.12170075,20.3424308 7.17157288,19.6923882 L4.75709327,18.8875616 C4.49512161,18.8002377 4.35354162,18.5170777 4.4408655,18.2551061 C4.46541191,18.1814669 4.50676633,18.114554 4.56165376,18.0596666 L7.21292558,15.4083948 C7.8216461,14.7996742 8.75158901,14.6487653 9.52156634,15.0337539 L9.77132688,15.1586342 C10.5413042,15.5436229 11.4712471,15.3927139 12.0799676,14.7839934 Z" fill="#000000"/>
																<rect fill="#000000" opacity="0.2" x="4" y="21" width="16" height="2" rx="1"/>
															</g>
														</svg>

														<h3 class="kt-iconbox__title text-center" style="
    font-size: 15px;
">
															24/7 SUPPORT
														</h3>
														
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div style="background: url(<?= base_url('assetsprofile/')?>asset/images/latarnew.jpeg); padding-top: 50px; padding-bottom: 40px; height:100%;">
							<h2 class="text-center mb-5" style='color:white; '>Produk Kami </h2>
							<div class="kt-container ">
								<div class="row">
									<div class="col-lg-4">
										<!--<div class="kt-portlet kt-iconbox kt-iconbox--success kt-iconbox--animate-slow">-->
										    <div class="">
											<div class="kt-portlet__body">
												<div class="kt-iconbox__body">
													<div class="kt-iconbox__icon">
														<!--<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">-->
														<!--	<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">-->
														<!--		<polygon points="0 0 24 0 24 24 0 24"/>-->
														<!--		<path d="M18,14 C16.3431458,14 15,12.6568542 15,11 C15,9.34314575 16.3431458,8 18,8 C19.6568542,8 21,9.34314575 21,11 C21,12.6568542 19.6568542,14 18,14 Z M9,11 C6.790861,11 5,9.209139 5,7 C5,4.790861 6.790861,3 9,3 C11.209139,3 13,4.790861 13,7 C13,9.209139 11.209139,11 9,11 Z" fill="#000000" fill-rule="nonzero" opacity="0.3"/>-->
														<!--		<path d="M17.6011961,15.0006174 C21.0077043,15.0378534 23.7891749,16.7601418 23.9984937,20.4 C24.0069246,20.5466056 23.9984937,21 23.4559499,21 L19.6,21 C19.6,18.7490654 18.8562935,16.6718327 17.6011961,15.0006174 Z M0.00065168429,20.1992055 C0.388258525,15.4265159 4.26191235,13 8.98334134,13 C13.7712164,13 17.7048837,15.2931929 17.9979143,20.2 C18.0095879,20.3954741 17.9979143,21 17.2466999,21 C13.541124,21 8.03472472,21 0.727502227,21 C0.476712155,21 -0.0204617505,20.45918 0.00065168429,20.1992055 Z" fill="#000000" fill-rule="nonzero"/>-->
														<!--	</g>-->
														<!--</svg>					-->
													</div>
													<div class="kt-iconbox__desc">
														<h3 class="kt-iconbox__title" style="
    text-align: center;
">
															<a class="kt-link" href="<?= base_url('auth/registration')?>" style='color:aqua; '>Enterprise</a>
														</h3>
														<div class="kt-iconbox__content" style='color:white; text-align: center; font-size: 23px;
    font-weight: 800;'>
															Pemodalan <br> untuk perusahaan 
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-4">
										<!--<div class="kt-portlet kt-iconbox kt-iconbox--warning kt-iconbox--animate-slow">-->
										    <div class="">
											<div class="kt-portlet__body">
												<div class="kt-iconbox__body">
													<div class="kt-iconbox__icon">
								<!--						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">-->
								<!--	<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">-->
								<!--		<rect x="0" y="0" width="24" height="24"></rect>-->
								<!--		<path d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z" fill="#000000" opacity="0.3"></path>-->
								<!--		<path d="M10.875,15.75 C10.6354167,15.75 10.3958333,15.6541667 10.2041667,15.4625 L8.2875,13.5458333 C7.90416667,13.1625 7.90416667,12.5875 8.2875,12.2041667 C8.67083333,11.8208333 9.29375,11.8208333 9.62916667,12.2041667 L10.875,13.45 L14.0375,10.2875 C14.4208333,9.90416667 14.9958333,9.90416667 15.3791667,10.2875 C15.7625,10.6708333 15.7625,11.2458333 15.3791667,11.6291667 L11.5458333,15.4625 C11.3541667,15.6541667 11.1145833,15.75 10.875,15.75 Z" fill="#000000"></path>-->
								<!--		<path d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z" fill="#000000"></path>-->
								<!--	</g>-->
								<!--</svg>				-->
								</div>
													<div class="kt-iconbox__desc">
														<h3 class="kt-iconbox__title" style="
    text-align: center;
">
															<a class="kt-link" href="<?= base_url('auth/registration')?>" style='color:aqua; '>Proyek</a>
														</h3>
														<div class="kt-iconbox__content" style='color:white; text-align: center; font-size: 23px;
    font-weight: 800; '>
															Pemodal <br> untuk perorangan
														</div>
													</div>
													
													
												</div>
											</div>
										</div>
									</div>
										<div class="col-lg-4">
										<!--<div class="kt-portlet kt-iconbox kt-iconbox--warning kt-iconbox--animate-slow">-->
										    <div class="">
											<div class="kt-portlet__body">
												<div class="kt-iconbox__body">
													<div class="kt-iconbox__icon">
								<!--						<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">-->
								<!--	<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">-->
								<!--		<rect x="0" y="0" width="24" height="24"></rect>-->
								<!--		<path d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z" fill="#000000" opacity="0.3"></path>-->
								<!--		<path d="M10.875,15.75 C10.6354167,15.75 10.3958333,15.6541667 10.2041667,15.4625 L8.2875,13.5458333 C7.90416667,13.1625 7.90416667,12.5875 8.2875,12.2041667 C8.67083333,11.8208333 9.29375,11.8208333 9.62916667,12.2041667 L10.875,13.45 L14.0375,10.2875 C14.4208333,9.90416667 14.9958333,9.90416667 15.3791667,10.2875 C15.7625,10.6708333 15.7625,11.2458333 15.3791667,11.6291667 L11.5458333,15.4625 C11.3541667,15.6541667 11.1145833,15.75 10.875,15.75 Z" fill="#000000"></path>-->
								<!--		<path d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z" fill="#000000"></path>-->
								<!--	</g>-->
								<!--</svg>				-->
								</div>
													<div class="kt-iconbox__desc">
														<h3 class="kt-iconbox__title" style="
    text-align: center;
">
															<a class="kt-link" href="<?= base_url('auth/registration')?>" style='color:aqua; '>UKM</a>
														</h3>
														<div class="kt-iconbox__content" style='color:white; text-align: center; font-size: 23px;
    font-weight: 800; '>
															Pemodalan <br> untuk UKM dan Koperasi
														</div>
													</div>
													
													
												</div>
											</div>
										</div>
									</div>
									
								</div>
							</div>
							</div>
							
							
							<div class="row" style="margin-top:57px !important; margin:15px;">
									<div class="col-lg-2" style="padding: 20px;">
									    <div style="background:#2c99e6; width:20px; border-radius:30px; color:white; margin:auto; text-align:center;">1</div>
									    <img style="
										border: white 3px solid;
                                        border-radius: 38px 0;
                                        width: 100%;
                                        height: 150px;
                                        object-fit: cover;
                                        object-position: center;
                                        image-orientation: inherit;
                                        margin-top: 20px;" 
                                        src="<?= base_url('assetsprofile/')?>asset/images/gambar1.jpeg">
                                        
                                        <p style="margin-top: 10px;
                                        color: #000000;
                                        font-weight: 400;
                                        margin-bottom: 1rem;
                                        text-align: center;">
                                        Calon penerbit memiliki proyek namun tidak memiliki dana.</p>
                                        
									</div>
									<div class="col-lg-2" style="padding: 20px;">
									    <div style="background:#2c99e6; width:20px; border-radius:30px; color:white; margin:auto; text-align:center;">2</div>
									    <img style="
										border: white 3px solid;
                                        border-radius: 38px 0;
                                        width: 100%;
                                        height: 150px;
                                        object-fit: cover;
                                        object-position: center;
                                        image-orientation: inherit;
                                        margin-top: 20px;" 
                                        src="<?= base_url('assetsprofile/')?>asset/images/gambar2.jpeg">
                                        
                                        <p style="margin-top: 10px;
                                        color: #000000;
                                        font-weight: 400;
                                        margin-bottom: 1rem;
                                        text-align: center;">
                                        Calon penerbit melakukan pengajuan pendanaan  melalui platform.
</p>
									</div>
									<div class="col-lg-2" style="padding: 20px;">
									    <div style="background:#2c99e6; width:20px; border-radius:30px; color:white; margin:auto; text-align:center;">3</div>
									    <img style="
										border: white 3px solid;
                                        border-radius: 38px 0;
                                        width: 100%;
                                        height: 150px;
                                        object-fit: cover;
                                        object-position: center;
                                        image-orientation: inherit;
                                        margin-top: 20px;" 
                                        src="<?= base_url('assetsprofile/')?>asset/images/gambar3.jpeg">
                                        
                                        <p style="margin-top: 10px;
                                        color: #000000;
                                        font-weight: 400;
                                        margin-bottom: 1rem;
                                        text-align: center;">
                                        Fulusme Sekuritas melakukan analisa data.
</p>
									</div>
									<div class="col-lg-2" style="padding: 20px;">
									    <div style="background:#2c99e6; width:20px; border-radius:30px; color:white; margin:auto; text-align:center;">4</div>
									    <img style="
										border: white 3px solid;
                                        border-radius: 38px 0;
                                        width: 100%;
                                        height: 150px;
                                        object-fit: cover;
                                        object-position: center;
                                        image-orientation: inherit;
                                        margin-top: 20px;" 
                                        src="<?= base_url('assetsprofile/')?>asset/images/gambar4.jpeg">
                                        
                                        <p style="margin-top: 10px;
                                        color: #000000;
                                        font-weight: 400;
                                        margin-bottom: 1rem;
                                        text-align: center;">
                                        Pemodal memilih proyek. 
</p>
									</div>
									<div class="col-lg-2" style="padding: 20px;">
									    <div style="background:#2c99e6; width:20px; border-radius:30px; color:white; margin:auto; text-align:center;">5</div>
									    <img style="
										border: white 3px solid;
                                        border-radius: 38px 0;
                                        width: 100%;
                                        height: 150px;
                                        object-fit: cover;
                                        object-position: center;
                                        image-orientation: inherit;
                                        margin-top: 20px;" 
                                        src="<?= base_url('assetsprofile/')?>asset/images/gambar5.jpeg">
                                        
                                        <p style="margin-top: 10px;
                                        color: #000000;
                                        font-weight: 400;
                                        margin-bottom: 1rem;
                                        text-align: center;">
                                        Penerbit mendapatkan pemodalan.

</p>
									</div>
									<div class="col-lg-2" style="padding: 20px;">
									    <div style="background:#2c99e6; width:20px; border-radius:30px; color:white; margin:auto; text-align:center;">6</div>
									    <img style="
										border: white 3px solid;
                                        border-radius: 38px 0;
                                        width: 100%;
                                        height: 150px;
                                        object-fit: cover;
                                        object-position: center;
                                        image-orientation: inherit;
                                        margin-top: 20px;" 
                                        src="<?= base_url('assetsprofile/')?>asset/images/gambar6.jpeg">
                                        
                                        <p style="margin-top: 10px;
                                        color: #000000;
                                        font-weight: 400;
                                        margin-bottom: 1rem;
                                        text-align: center;">
                                        Pemodal mendapatkan dividen dan keuntungan. 
</p>
									</div>
							</div>
							
							
							<div style="padding-top: 50px;
    background-repeat: repeat-x;
    background-repeat-x: initial;
    background-repeat-y: initial;
    background-attachment: scroll;
    background-position: left;
    ">
							    <div class="kt-container  kt-grid__item kt-grid__item--fluid">
		                            <!--begin:: Portlet-->
		                            
		                            
		                            <?php
		                           foreach ($project as $obj) {
   
   
   
   
                                   ?> 
                                   
                                   
                                   <div class="kt-portlet ">
                                        <div class="kt-portlet__body">
                                            <div class="kt-widget kt-widget--user-profile-3">
                                                <div class="kt-widget__top">
                                                    <div class="kt-widget__media kt-hidden-" style="    height: 200px;
    width: 200px;">
                                                        
                                                        
                                        <img class="card_holder_img" style="width: 200px;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;" src="<?php   echo base_url('assets/'). "img/profile/".$obj["image"]
                                        
                                        ?> ">

                            </div>
                                                    <div class="kt-widget__pic kt-widget__pic--danger kt-font-danger kt-font-boldest kt-font-light kt-hidden">
                                                        JM
                                                    </div>
                                                    <div class="kt-widget__content">
                                                        <div class="kt-widget__head">
                                                            <a href="#" class="kt-widget__username kt-hidden">
                                                                Jason Muller    
                                                                <i class="flaticon2-correct"></i>                       
                                                            </a>
                                    
                                                            <a href="#" class="kt-widget__title"><?php   echo $obj["nama_project"]?></a>
                                    
                                                            <div class="kt-widget__action">
                                                                <button type="button" class="btn btn-sm btn-upper" style="background: #edeff6">Download Prospektus</button>&nbsp;
                                                                <button type="button" class="btn btn-brand btn-sm btn-upper">Beli</button>
                                                              <div class="kt-widget__item" style="display: inline-block;">
                                                                    <span class="kt-widget__date">
                                                                         Rating Project : 
                                                                 </span>
                                                                    <div class="kt-widget__label-success">
                                                                        <span class="btn btn-label-brand btn-sm btn-bold btn-upper">Profil Perusahaan</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                    
                                                    
                                    
                                                        <div class="kt-widget__info">
                                                            <div class="kt-widget__desc">
                                                                <p>Code Proyek : <?php   echo $obj["id"]?></p>
                                                               
                                                                <div class="kt-widget__text">
                                                                    Saham Terjual
                                                                </div>
                                                                <div class="progress" style="height: 5px;width: 100%;">
                                                                    <div class="progress-bar kt-bg-success" role="progressbar" style="width: 65%;" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                                <div class="kt-widget__stats">
                                                                    78%
                                                                </div>
                                                                
                                                                <div class="kt-widget__text">
                                                                    Sisa Waktu
                                                                </div>
                                                                <div class="progress" style="height: 5px;width: 100%;">
                                                                    <div class="progress-bar kt-bg-success" role="progressbar" style="width: 65%;" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                                <div class="kt-widget__stats">
                                                                    78%
                                                                </div>
                                                            
                                                            </div>
                                                            
                                    
                                                            <div class="kt-widget__stats d-flex align-items-center flex-fill">
                                                                <div class="kt-widget__item">
                                                                    <span class="kt-widget__date">
                                                                        Rating Proyek : 
                                                                    </span>
                                                                    <div class="kt-widget__label-success">
                                                                        <span class="btn btn-label-brand btn-sm btn-bold btn-upper">4/5</span>
                                                                    </div>
                                                                </div>
                                    
                                                               
                                    
                                                               
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="kt-widget__bottom">
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z" fill="#000000" opacity="0.3" transform="translate(11.500000, 12.000000) rotate(-345.000000) translate(-11.500000, -12.000000) "/>
        <path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z M11.5,14 C12.6045695,14 13.5,13.1045695 13.5,12 C13.5,10.8954305 12.6045695,10 11.5,10 C10.3954305,10 9.5,10.8954305 9.5,12 C9.5,13.1045695 10.3954305,14 11.5,14 Z" fill="#000000"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;" >Total Pendanaan</span>
                                                            <span class="kt-widget__value"><span>Rp. </span>249.500.000</span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                           <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M10.9630156,7.5 L11.0475062,7.5 C11.3043819,7.5 11.5194647,7.69464724 11.5450248,7.95024814 L12,12.5 L15.2480695,14.3560397 C15.403857,14.4450611 15.5,14.6107328 15.5,14.7901613 L15.5,15 C15.5,15.2109164 15.3290185,15.3818979 15.1181021,15.3818979 C15.0841582,15.3818979 15.0503659,15.3773725 15.0176181,15.3684413 L10.3986612,14.1087258 C10.1672824,14.0456225 10.0132986,13.8271186 10.0316926,13.5879956 L10.4644883,7.96165175 C10.4845267,7.70115317 10.7017474,7.5 10.9630156,7.5 Z" fill="#000000"/>
        <path d="M7.38979581,2.8349582 C8.65216735,2.29743306 10.0413491,2 11.5,2 C17.2989899,2 22,6.70101013 22,12.5 C22,18.2989899 17.2989899,23 11.5,23 C5.70101013,23 1,18.2989899 1,12.5 C1,11.5151324 1.13559454,10.5619345 1.38913364,9.65805651 L3.31481075,10.1982117 C3.10672013,10.940064 3,11.7119264 3,12.5 C3,17.1944204 6.80557963,21 11.5,21 C16.1944204,21 20,17.1944204 20,12.5 C20,7.80557963 16.1944204,4 11.5,4 C10.54876,4 9.62236069,4.15592757 8.74872191,4.45446326 L9.93948308,5.87355717 C10.0088058,5.95617272 10.0495583,6.05898805 10.05566,6.16666224 C10.0712834,6.4423623 9.86044965,6.67852665 9.5847496,6.69415008 L4.71777931,6.96995273 C4.66931162,6.97269931 4.62070229,6.96837279 4.57348157,6.95710938 C4.30487471,6.89303938 4.13906482,6.62335149 4.20313482,6.35474463 L5.33163823,1.62361064 C5.35654118,1.51920756 5.41437908,1.4255891 5.49660017,1.35659741 C5.7081375,1.17909652 6.0235153,1.2066885 6.2010162,1.41822583 L7.38979581,2.8349582 Z" fill="#000000" opacity="0.3"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Periode Deviden</span>
                                                            <span class="kt-widget__value"><?php   echo $obj["tenor"]?> Bulan</span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M5.94290508,4 L18.0570949,4 C18.5865712,4 19.0242774,4.41271535 19.0553693,4.94127798 L19.8754445,18.882556 C19.940307,19.9852194 19.0990032,20.9316862 17.9963398,20.9965487 C17.957234,20.9988491 17.9180691,21 17.8788957,21 L6.12110428,21 C5.01653478,21 4.12110428,20.1045695 4.12110428,19 C4.12110428,18.9608266 4.12225519,18.9216617 4.12455553,18.882556 L4.94463071,4.94127798 C4.97572263,4.41271535 5.41342877,4 5.94290508,4 Z" fill="#000000" opacity="0.3"/>
        <path d="M7,7 L9,7 C9,8.65685425 10.3431458,10 12,10 C13.6568542,10 15,8.65685425 15,7 L17,7 C17,9.76142375 14.7614237,12 12,12 C9.23857625,12 7,9.76142375 7,7 Z" fill="#000000"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Harga Per Lembar saham</span>
                                                            <span class="kt-widget__value"><span>Rp.</span>84.060</span>(Minimum Pembelian 1 Lot)
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M13.5,21 L13.5,18 C13.5,17.4477153 13.0522847,17 12.5,17 L11.5,17 C10.9477153,17 10.5,17.4477153 10.5,18 L10.5,21 L5,21 L5,4 C5,2.8954305 5.8954305,2 7,2 L17,2 C18.1045695,2 19,2.8954305 19,4 L19,21 L13.5,21 Z M9,4 C8.44771525,4 8,4.44771525 8,5 L8,6 C8,6.55228475 8.44771525,7 9,7 L10,7 C10.5522847,7 11,6.55228475 11,6 L11,5 C11,4.44771525 10.5522847,4 10,4 L9,4 Z M14,4 C13.4477153,4 13,4.44771525 13,5 L13,6 C13,6.55228475 13.4477153,7 14,7 L15,7 C15.5522847,7 16,6.55228475 16,6 L16,5 C16,4.44771525 15.5522847,4 15,4 L14,4 Z M9,8 C8.44771525,8 8,8.44771525 8,9 L8,10 C8,10.5522847 8.44771525,11 9,11 L10,11 C10.5522847,11 11,10.5522847 11,10 L11,9 C11,8.44771525 10.5522847,8 10,8 L9,8 Z M9,12 C8.44771525,12 8,12.4477153 8,13 L8,14 C8,14.5522847 8.44771525,15 9,15 L10,15 C10.5522847,15 11,14.5522847 11,14 L11,13 C11,12.4477153 10.5522847,12 10,12 L9,12 Z M14,12 C13.4477153,12 13,12.4477153 13,13 L13,14 C13,14.5522847 13.4477153,15 14,15 L15,15 C15.5522847,15 16,14.5522847 16,14 L16,13 C16,12.4477153 15.5522847,12 15,12 L14,12 Z" fill="#000000"/>
        <rect fill="#FFFFFF" x="13" y="8" width="3" height="3" rx="1"/>
        <path d="M4,21 L20,21 C20.5522847,21 21,21.4477153 21,22 L21,22.4 C21,22.7313708 20.7313708,23 20.4,23 L3.6,23 C3.26862915,23 3,22.7313708 3,22.4 L3,22 C3,21.4477153 3.44771525,21 4,21 Z" fill="#000000" opacity="0.3"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">

                                                                 
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Jumlah Saham yang diterbitkan</span>
                                                            <span class="kt-widget__value">10.000.000 Lembar Saham</span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                           <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M5,19 L20,19 C20.5522847,19 21,19.4477153 21,20 C21,20.5522847 20.5522847,21 20,21 L4,21 C3.44771525,21 3,20.5522847 3,20 L3,4 C3,3.44771525 3.44771525,3 4,3 C4.55228475,3 5,3.44771525 5,4 L5,19 Z" fill="#000000" fill-rule="nonzero"/>
        <path d="M8.7295372,14.6839411 C8.35180695,15.0868534 7.71897114,15.1072675 7.31605887,14.7295372 C6.9131466,14.3518069 6.89273254,13.7189711 7.2704628,13.3160589 L11.0204628,9.31605887 C11.3857725,8.92639521 11.9928179,8.89260288 12.3991193,9.23931335 L15.358855,11.7649545 L19.2151172,6.88035571 C19.5573373,6.44687693 20.1861655,6.37289714 20.6196443,6.71511723 C21.0531231,7.05733733 21.1271029,7.68616551 20.7848828,8.11964429 L16.2848828,13.8196443 C15.9333973,14.2648593 15.2823707,14.3288915 14.8508807,13.9606866 L11.8268294,11.3801628 L8.7295372,14.6839411 Z" fill="#000000" fill-rule="nonzero" opacity="0.3"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Harga Per 1 Lot Saham</span>
                                                            <span class="kt-widget__value">Rp. 200.000.000</span>(Per 1 Lot 100 Lembar saham)
                                                        </div>
                                                    </div>
                                    
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   
                                   
                                   
                                   
                                   
                                   
                                   
                                   <?php }
		                            
		                            ?>
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            <?php
		                            foreach ($project_retail as $obj){
		                            
		                            ?>
		                             <div class="kt-portlet ">
                                        <div class="kt-portlet__body">
                                            <div class="kt-widget kt-widget--user-profile-3">
                                                <div class="kt-widget__top">
                                                    <div class="kt-widget__media kt-hidden-" style="    height: 200px;
    width: 200px;">
                                                        <img src="https://www.fintekmadani.id/assets/img/profile/<?php echo $obj["foto_toko"]?>" style="
    height: 100%;
    width: 100%;
"alt="image">
                                                    </div>
                                                    <div class="kt-widget__pic kt-widget__pic--danger kt-font-danger kt-font-boldest kt-font-light kt-hidden">
                                                        JM
                                                    </div>
                                                    <div class="kt-widget__content">
                                                        <div class="kt-widget__head">
                                                            <a href="#" class="kt-widget__username kt-hidden">
                                                                Jason Muller    
                                                                <i class="flaticon2-correct"></i>                       
                                                            </a>
                                    
                                                            <a href="#" class="kt-widget__title"><?php   echo $obj["nama_toko"]?> - <?php   echo $obj["nama_pemilik"]?></a>
                                    
                                                            <div class="kt-widget__action">
                                                                <button type="button" class="btn btn-sm btn-upper" style="background: #edeff6">profil proyek</button>&nbsp;
                                                                <button type="button" class="btn btn-brand btn-sm btn-upper">Beli</button>
                                                                <!--<div class="kt-widget__item" style="display: inline-block;">-->
                                                                <!--    <span class="kt-widget__date">-->
                                                                <!--        Rating Project : -->
                                                                <!--    </span>-->
                                                                <!--    <div class="kt-widget__label-success">-->
                                                                <!--        <span class="btn btn-label-brand btn-sm btn-bold btn-upper">4/5</span>-->
                                                                <!--    </div>-->
                                                                <!--</div>-->
                                                            </div>
                                                        </div>
                                    
                                                    
                                    
                                                        <div class="kt-widget__info">
                                                            <div class="kt-widget__desc">
                                                                <p>Id Project : <?php   echo $obj["id_project"]?></p>
                                                               
                                                                <!--<div class="kt-widget__text">-->
                                                                <!--    Dana Terkumpul-->
                                                                <!--</div>-->
                                                                
                                                                <p  style=" display: inline-block; margin-bottom: 0;">
                                                                    Dana Terkumpul
                                                                </p>
                                                                
                                                                <p style="margin-bottom: 0;
    display: inline-block;
    position: initial;
    float: right;
">
<?php   echo number_format
($obj["nominal"]/$obj["jumlah_pinjaman"]*100,1)?>%
                                                                    
                                                                </p>
                                                                <div class="progress" style="height: 5px;width: 100%;">
                                                                    <div class="progress-bar kt-bg-success" role="progressbar" style="width: <?php   echo ($obj["nominal"]/$obj["jumlah_pinjaman"]*100)?>%;" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                                
                                                                <div class="kt-widget__stats">
                                                                    <?php   echo rupiah($obj["nominal"])?>
                                                                </div>
                                                                
                                                               <p  style=" display: inline-block; margin-bottom: 0;">
                                                                   Sisa Waktu
                                                                </p>
                                                                
                                                                <p style="margin-bottom: 0;
    display: inline-block;
    position: initial;
    float: right;
">
<?php   echo date("d F Y", $obj['end_ts'])?>
                                                                    
                                                                </p>
                                                                <div class="progress" style="height: 5px;width: 100%;">
                                                                    <div class="progress-bar kt-bg-success" role="progressbar" style="width:<?php echo 100-((((new Datetime(date("d F Y")))->diff(new DateTime(date("d F Y", $obj['end_ts'])))->format('%R%a'))/3*100)); ?>%;" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                                                </div>
                                                                <div class="kt-widget__stats">
                                                                    <?php echo str_replace('+', '', (new Datetime(date("d F Y")))->diff(new DateTime(date("d F Y", $obj['end_ts'])))->format('%R%a')); ?> Hari 
                                                                  
                                                                </div>
                                                            
                                                            </div>
                                                            
                                    
                                                            <div class="kt-widget__stats d-flex align-items-center flex-fill">
                                                                <?php if ($obj['nominal']==$obj['jumlah_pinjaman']){?>
                                    <img style="    width: 35%;" src="https://www.fintekmadani.id/assetsprofile/asset/images/terdanai.jpeg">
                                                               
                                     <?php }?>
                                                               
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="kt-widget__bottom">
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z" fill="#000000" opacity="0.3" transform="translate(11.500000, 12.000000) rotate(-345.000000) translate(-11.500000, -12.000000) "/>
        <path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z M11.5,14 C12.6045695,14 13.5,13.1045695 13.5,12 C13.5,10.8954305 12.6045695,10 11.5,10 C10.3954305,10 9.5,10.8954305 9.5,12 C9.5,13.1045695 10.3954305,14 11.5,14 Z" fill="#000000"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;" >Jumlah Pendanaan</span>
                                                            <span class="kt-widget__value"><?php  echo rupiah($obj["jumlah_pinjaman"])?></span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                           <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M10.9630156,7.5 L11.0475062,7.5 C11.3043819,7.5 11.5194647,7.69464724 11.5450248,7.95024814 L12,12.5 L15.2480695,14.3560397 C15.403857,14.4450611 15.5,14.6107328 15.5,14.7901613 L15.5,15 C15.5,15.2109164 15.3290185,15.3818979 15.1181021,15.3818979 C15.0841582,15.3818979 15.0503659,15.3773725 15.0176181,15.3684413 L10.3986612,14.1087258 C10.1672824,14.0456225 10.0132986,13.8271186 10.0316926,13.5879956 L10.4644883,7.96165175 C10.4845267,7.70115317 10.7017474,7.5 10.9630156,7.5 Z" fill="#000000"/>
        <path d="M7.38979581,2.8349582 C8.65216735,2.29743306 10.0413491,2 11.5,2 C17.2989899,2 22,6.70101013 22,12.5 C22,18.2989899 17.2989899,23 11.5,23 C5.70101013,23 1,18.2989899 1,12.5 C1,11.5151324 1.13559454,10.5619345 1.38913364,9.65805651 L3.31481075,10.1982117 C3.10672013,10.940064 3,11.7119264 3,12.5 C3,17.1944204 6.80557963,21 11.5,21 C16.1944204,21 20,17.1944204 20,12.5 C20,7.80557963 16.1944204,4 11.5,4 C10.54876,4 9.62236069,4.15592757 8.74872191,4.45446326 L9.93948308,5.87355717 C10.0088058,5.95617272 10.0495583,6.05898805 10.05566,6.16666224 C10.0712834,6.4423623 9.86044965,6.67852665 9.5847496,6.69415008 L4.71777931,6.96995273 C4.66931162,6.97269931 4.62070229,6.96837279 4.57348157,6.95710938 C4.30487471,6.89303938 4.13906482,6.62335149 4.20313482,6.35474463 L5.33163823,1.62361064 C5.35654118,1.51920756 5.41437908,1.4255891 5.49660017,1.35659741 C5.7081375,1.17909652 6.0235153,1.2066885 6.2010162,1.41822583 L7.38979581,2.8349582 Z" fill="#000000" opacity="0.3"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Tenor</span>
                                                            <span class="kt-widget__value"><?echo $obj["tenor"]?> Hari</span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M5.94290508,4 L18.0570949,4 C18.5865712,4 19.0242774,4.41271535 19.0553693,4.94127798 L19.8754445,18.882556 C19.940307,19.9852194 19.0990032,20.9316862 17.9963398,20.9965487 C17.957234,20.9988491 17.9180691,21 17.8788957,21 L6.12110428,21 C5.01653478,21 4.12110428,20.1045695 4.12110428,19 C4.12110428,18.9608266 4.12225519,18.9216617 4.12455553,18.882556 L4.94463071,4.94127798 C4.97572263,4.41271535 5.41342877,4 5.94290508,4 Z" fill="#000000" opacity="0.3"/>
        <path d="M7,7 L9,7 C9,8.65685425 10.3431458,10 12,10 C13.6568542,10 15,8.65685425 15,7 L17,7 C17,9.76142375 14.7614237,12 12,12 C9.23857625,12 7,9.76142375 7,7 Z" fill="#000000"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Harga Per saham</span>
                                                            <span class="kt-widget__value"><span>Rp.</span>1.000.000</span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M13.5,21 L13.5,18 C13.5,17.4477153 13.0522847,17 12.5,17 L11.5,17 C10.9477153,17 10.5,17.4477153 10.5,18 L10.5,21 L5,21 L5,4 C5,2.8954305 5.8954305,2 7,2 L17,2 C18.1045695,2 19,2.8954305 19,4 L19,21 L13.5,21 Z M9,4 C8.44771525,4 8,4.44771525 8,5 L8,6 C8,6.55228475 8.44771525,7 9,7 L10,7 C10.5522847,7 11,6.55228475 11,6 L11,5 C11,4.44771525 10.5522847,4 10,4 L9,4 Z M14,4 C13.4477153,4 13,4.44771525 13,5 L13,6 C13,6.55228475 13.4477153,7 14,7 L15,7 C15.5522847,7 16,6.55228475 16,6 L16,5 C16,4.44771525 15.5522847,4 15,4 L14,4 Z M9,8 C8.44771525,8 8,8.44771525 8,9 L8,10 C8,10.5522847 8.44771525,11 9,11 L10,11 C10.5522847,11 11,10.5522847 11,10 L11,9 C11,8.44771525 10.5522847,8 10,8 L9,8 Z M9,12 C8.44771525,12 8,12.4477153 8,13 L8,14 C8,14.5522847 8.44771525,15 9,15 L10,15 C10.5522847,15 11,14.5522847 11,14 L11,13 C11,12.4477153 10.5522847,12 10,12 L9,12 Z M14,12 C13.4477153,12 13,12.4477153 13,13 L13,14 C13,14.5522847 13.4477153,15 14,15 L15,15 C15.5522847,15 16,14.5522847 16,14 L16,13 C16,12.4477153 15.5522847,12 15,12 L14,12 Z" fill="#000000"/>
        <rect fill="#FFFFFF" x="13" y="8" width="3" height="3" rx="1"/>
        <path d="M4,21 L20,21 C20.5522847,21 21,21.4477153 21,22 L21,22.4 C21,22.7313708 20.7313708,23 20.4,23 L3.6,23 C3.26862915,23 3,22.7313708 3,22.4 L3,22 C3,21.4477153 3.44771525,21 4,21 Z" fill="#000000" opacity="0.3"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">

                                                                 
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">(Jasa Platform 5%)</span>
                                                            <span class="kt-widget__value"><?echo rupiah($obj["Jasa Platform"])?></span>
                                                        </div>
                                                    </div>
                                    
                                                    <div class="kt-widget__item" style="margin: 0;
    padding: 0;">
                                                        <div class="kt-widget__icon">
                                                           <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" class="kt-svg-icon">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <rect x="0" y="0" width="24" height="24"/>
        <path d="M5,19 L20,19 C20.5522847,19 21,19.4477153 21,20 C21,20.5522847 20.5522847,21 20,21 L4,21 C3.44771525,21 3,20.5522847 3,20 L3,4 C3,3.44771525 3.44771525,3 4,3 C4.55228475,3 5,3.44771525 5,4 L5,19 Z" fill="#000000" fill-rule="nonzero"/>
        <path d="M8.7295372,14.6839411 C8.35180695,15.0868534 7.71897114,15.1072675 7.31605887,14.7295372 C6.9131466,14.3518069 6.89273254,13.7189711 7.2704628,13.3160589 L11.0204628,9.31605887 C11.3857725,8.92639521 11.9928179,8.89260288 12.3991193,9.23931335 L15.358855,11.7649545 L19.2151172,6.88035571 C19.5573373,6.44687693 20.1861655,6.37289714 20.6196443,6.71511723 C21.0531231,7.05733733 21.1271029,7.68616551 20.7848828,8.11964429 L16.2848828,13.8196443 C15.9333973,14.2648593 15.2823707,14.3288915 14.8508807,13.9606866 L11.8268294,11.3801628 L8.7295372,14.6839411 Z" fill="#000000" fill-rule="nonzero" opacity="0.3"/>
    </g>
</svg>
                                                        </div>
                                                        <div class="kt-widget__details">
                                                            <span class="kt-widget__title" style="color: #d8d8d8;
    font-weight: 400;">Estimasi Net Profit</span>
                                                            <span class="kt-widget__value"><?echo rupiah($obj["nisbah"])?></span>
                                                        </div>
                                                    </div>
                                    
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php }
		                            
		                            ?>
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                            
		                           
                                    
	                            </div>
							    
							</div>

						

						



							<!-- end:: Content -->
							 
						</div>
					</div>

