
		<!-- Logo and Navigation -->
		<div class="site-header-container container">

			<div class="row">

				<div class="col-md-12">

					<header class="site-header">

						<section class="site-logo">

							<a href="index.php">
					<img src="<?= base_url('assetsprofile/')?>asset/images/dealfintech.jpg" width="90" />
								
							
		</a>


						</section>

				<p style="
    text-transform: small-caps;
    margin: 41px;
    color: #6d1514;
    font-weight: 100;
    font-size: 55px;
">
		<b>Fulusme  Will be Ready Soon</p>
					</header>

				</div>

			</div>

		</div>	

		<!-- Main Slider -->


				<div class="container-fluid">
  		<div class="row" style="margin-bottom: 100px ">
<div class="col-md-12" style="padding: 0;">
    
    <img style="
    width: 100%;" src="<?= base_url('assetsprofile/')?>asset/images/FA_TEMPLATES-min.jpg">
</div> 

				<p style="
			
    text-transform: small-caps;
    margin: 41px;
    color: #6d1514;
    font-weight: 100;
    font-size: 55px;
">
			<b>Sorry We are still Under Construction</p>
				</div>


<!--div class="col-md-5 " style="text-align: right">-->
  				
<!--  				<h1 style="-->
<!--    font-size: 100px;-->
<!--    margin-bottom: 40px;margin-top: 50px; color: #dbdae5;-->
<!--">Dirgahayu Indonesia </h1>-->
<!-- <h1 style="
<!--    font-size: 100px;-->
<!--    margin-bottom: 40px;margin-top: 50px; color: #C00000;     font-size: 74px;-->
<!--">FuLusme Mengucapkan</h1> -->

<!--  				<h2 style="padding-left: 300px;">Selamat Hari Kemerdekaan Indonesia </h2>-->
  				<!-- <h2 style="padding-left: 300px;">DIRGAHAYU REPUBLIK INDONESIA</h2> -->

<!--  				<p style="-->
<!--        padding-left: 200px;-->
<!--    margin-top: 36px;-->
<!--    font-size: 18px;-->
<!--    font-weight: 200;-->
<!--">Kami akan tersedia dalam waktu dekat, web ini akan tersedia dan siap untuk beroperasi, terimakasih</p>-->
<!--  			</div>-->

<!--  			<div class="col-md-7">-->
<!--  				<img style="-->
<!--    margin-left: 50px;-->
<!--" src="<?= base_url('assetsprofile/')?>asset/images/Group.png">-->
<!--  			</div>-->
  		</div>
</div>



	<!-- produk -->








<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=f50a8472-49e9-41b0-8efe-fbd25b64576e"> </script>

<!-- Client Logos -->

<!-- Footer Widgets -->
<section class="footer-widgets" style="margin-bottom: 0px; font-size: 10px">

	<div class="container">

		<div class="row">

			<div class="col-sm-6">
			    
			    <div class="col-sm-2">
			        <a href="index.php">
					    <img src="<?= base_url('assetsprofile/')?>asset/images/dealfintech.jpg" width="70" />
				    </a>
			    </div>
			    
			     <div class="col-sm-10">
			        <p style="
    margin-top: 25px;
">
					    Fulusme  adalah Layanan Urun Dana Berbasis Teknologi (Securities Crowd Funding), yang kami bangun untuk dapat bermanfaat bagi dunia bisnis di Indonesia.
				    </p>
			    </div>
			</div>

			<div class="col-sm-3">

				<h5>Alamat</h5>

			
					<p> PT. Fintek Andalan Solusi Teknologi <br>	
						Jl. Bendungan Hilir IV No.6 <br>
						Kecamatan Tanah Abang Jakarta Pusat,10210 <br>
						Indonesia.  <br></p>
					</p>

				</div>

				<div class="col-sm-3">

					<h5>Hubungi Kami</h5>

					<p>
						Phone:          +62 21 2520-934<br>
						Penerbit:       +62 21 2555-8986<br>
						Pemodal:        +62 21 2555-8986<br>
						UKM:            +62 21 2555-8986<br>
						E-mail:  info@fulusme.id <br>
						<img src="<?= base_url('assetsprofile/')?>asset/images/wa.png" width="13" />
						<a style="color:#999999;" href="https://api.whatsapp.com/send?phone=6282299996862&text=&source=&data=">+62 822 9999 6862</a>
						
						</p>

					</div>

				</div>

			</div>
			

