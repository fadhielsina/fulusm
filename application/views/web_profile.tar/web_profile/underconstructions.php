CTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Under Constructions</title>
        <link rel="stylesheet" href="http://idwebhost.com/underconstruction/underStyle.css" type="text/css" />
        <link rel="shortcut icon" href="http://idwebhost.com/underconstruction/favicon.ico" />
</head>
<body>
<div class="body">
        <div class="layout">

                <div id="logo">
                        <img src="http://idwebhost.com/underconstruction/logo.gif" alt="IDwebhost.com" />
                </div>
                <div class="container">
                        <h1>This page is underconstructions </h1>
                        <br />
                        <img src="http://idwebhost.com/underconstruction/under.png" />
                </div>
        </div>
</div>
</body>
</html>


