
<body>

	<div class="wrap">
		
	
		<!-- Breadcrumb --><section class="portfolio-item-details">
			
			<div class="container">
				
				<!-- Title and Item Details -->		<div class="row item-title">
					
					<div class="col-sm-12" style="margin-top:50px; text-align:center; ">
						<h3 style="color:#5fa5b1;">
						Alur Bisnis
						</h3>
						
						
					</div>
					
				
					
				</div>
				
				<!-- Portfolio Images Gallery -->		<div class="row">
					<div class="col-md-12">
						
						<div class="item-images">
							
							<a href="#">
								<img style="width:100%;" src="<?= base_url('assetsprofile/')?>asset/images/alurbisnis_new1.1.jpg" class="img-rounded" />
							</a>
							
							
						</div>
						
					</div>
				</div>
				
				
				
			
				
			</div>
			
		</section>

		
	
			</div>



		</body>

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-35VN14CNFE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-35VN14CNFE');
</script>
