
<body>

	<div class="wrap">
		
	
		<!-- Breadcrumb --><section class="portfolio-item-details" style="background:white;">
			
			<div class="container" >
				
				<!-- Title and Item Details -->		<div class="row item-title">
					
					<div class="col-sm-12" style="margin-top:50px;  ">
						<h3 style="color: #000;
    font-size: 55px;
    font-weight: 800;">
						Selamat Datang di Pasar Sekunder 
						</h3>
						
						<h3 style="color: #aaa;
    font-size: 20px;
    font-size: 20px;">
						Apa yang ingin anda lakukan ? 
						</h3>
						
						
					</div>
					
					
					<div class="col-sm-12" style="margin-top:50px; ">
					    	<div class="row item-title">
					   <div class="col-sm-6" >
					       <div style="    background: #1dc9b7;
    width: 60%;
    height: 137px;
    margin: 0 10% 0 auto;
    display: table;
    
    ">
					           
					           <div style="display: table-cell;
	text-align: center;
	vertical-align: middle;
	margin-bottom: 0;
    font-size: 19px;
    color: white;
	">
		<p>Jual Saham</p>
	</div>
					           
					       </div>
					       
					       
					   </div>
					   
					  <div class="col-sm-6" >
					       <div style="    background: #1dc9b7;
    width: 60%;
    height: 137px;
    margin: 0 auto 0 10%;
    display: table;
    
    ">
					           
					           <div style="display: table-cell;
	text-align: center;
	vertical-align: middle;
	margin-bottom: 0;
    font-size: 19px;
    color: white;
	">
		<p>Beli Saham</p>
	</div>
					           
					       </div>
					       
					       
					   </div>
					       
					   </div>
					   
					   
					   
					   
					   </div>
					    
					    
					</div>
					
				
				
				
				
				
				
				
				
				
				
					
				</div>
				
					<div class="container" style="margin-top:50px;">
				<h3 style="margin-bottom:30px">
				    List Saham
				</h3>
				
				<div class="card" style="margin-bottom:30px;">
  <div class="card-header" style="    background: #eee;
    font-weight: bold;">
    MULT
  </div>
  <div class="card-body">
      <div class="row">
          
           <div class="col-sm-6">
          <h5 class="card-title">Animasi Indonesia</h5>
    <p class="card-text" style="display: inline-block">Pt Multimedia Indotama</p>
      </div>
      
      
      <div class="col-sm-6 text-right">
          <p class="card-text" >Harga Terakhir</p>
    <p class="card-text" style="    font-size: 18px;
    font-weight: 600;
    margin-bottom: 0px;">Rp. 30.000</p>
     <p class="card-text text-success">+20%</p>
          
      </div>
      
      
      
      </div>
      
      
     
      
    
    
    <a href="#" class="btn btn-success">Beli</a>
  </div>
</div>









<div class="card" style="margin-bottom:30px;">
  <div class="card-header" style="    background: #eee;
    font-weight: bold;">
    MULT
  </div>
  <div class="card-body">
      <div class="row">
          
           <div class="col-sm-6">
          <h5 class="card-title">Animasi Indonesia</h5>
    <p class="card-text" style="display: inline-block">Pt Multimedia Indotama</p>
      </div>
      
      
      <div class="col-sm-6 text-right">
          <p class="card-text" >Harga Terakhir</p>
    <p class="card-text" style="    font-size: 18px;
    font-weight: 600;
    margin-bottom: 0px;">Rp. 30.000</p>
     <p class="card-text text-success">+20%</p>
          
      </div>
      
      
      
      </div>
      
      
     
      
    
    
    <a href="#" class="btn btn-success">Beli</a>
  </div>
</div>









<div class="card" style="margin-bottom:30px;">
  <div class="card-header" style="    background: #eee;
    font-weight: bold;">
    MULT
  </div>
  <div class="card-body">
      <div class="row">
          
           <div class="col-sm-6">
          <h5 class="card-title">Animasi Indonesia</h5>
    <p class="card-text" style="display: inline-block">Pt Multimedia Indotama</p>
      </div>
      
      
      <div class="col-sm-6 text-right">
          <p class="card-text" >Harga Terakhir</p>
    <p class="card-text" style="    font-size: 18px;
    font-weight: 600;
    margin-bottom: 0px;">Rp. 30.000</p>
     <p class="card-text text-success">+20%</p>
          
      </div>
      
      
      
      </div>
      
      
     
      
    
    
    <a href="#" class="btn btn-success">Beli</a>
  </div>
</div>









<div class="card" style="margin-bottom:30px;">
  <div class="card-header" style="    background: #eee;
    font-weight: bold;">
    MULT
  </div>
  <div class="card-body">
      <div class="row">
          
           <div class="col-sm-6">
          <h5 class="card-title">Animasi Indonesia</h5>
    <p class="card-text" style="display: inline-block">Pt Multimedia Indotama</p>
      </div>
      
      
      <div class="col-sm-6 text-right">
          <p class="card-text" >Harga Terakhir</p>
    <p class="card-text" style="    font-size: 18px;
    font-weight: 600;
    margin-bottom: 0px;">Rp. 30.000</p>
     <p class="card-text text-success">+20%</p>
          
      </div>
      
      
      
      </div>
      
      
     
      
    
    
    <a href="#" class="btn btn-success">Beli</a>
  </div>
</div>
				
				
				</div>
				
				
				<!-- Portfolio Images Gallery -->		<div class="row">
					<div class="col-md-12">
						
						<div class="item-images">
							
							<a href="#">
								<!--<img style="width:100%;" src="<?= base_url('assetsprofile/')?>asset/images/alurbisnis_new1.1.jpg" class="img-rounded" />-->
				<!-- Portfolio Images Gallery -->		
				
				
				<div class="row">
					<div class="col-md-12">
						
						<div class="item-images">
							
							<!--<a href="#">-->
							<!--	<img style="width:100%;" src="<?= base_url('assetsprofile/')?>asset/images/alur bisnis fulusme equitas1.1.jpg" class="img-rounded" />-->
							<!--</a>-->
							
							
						</div>
						
					</div>
				</div>
				
				
				
			
				
			</div>
			
		</section>

		
	
			</div>



		</body>

