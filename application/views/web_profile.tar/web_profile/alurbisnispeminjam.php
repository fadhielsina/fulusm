<div class="row border-responsive">
          <div class="col-md-12 col-lg-6 mb-4 mb-lg-0 border-right">
		   <div class="text-center" style="margin-top:6%;margin-bottom:6%;">
		   <span class="flaticon-medal display-4 d-block mb-3 text-primary"></span>
              <h3 class="text-uppercase h4 mb-3">Penjelasan Alur Bisnis</h3>
			  </div>
            <div class="text-left" style="margin:6%;">
             <ol>
			  <li>Penerbit mengajukan kebutuhan permodalan kepada penyelenggara</li>
			  <li>Penyelenggara melakukan asesmen dan review proposal penerbit</li>
			  <li>Jika proposal penerbit sudah di approval penyelenggara, maka penyelenggara membuat akad perjanjian dengan penerbit</li>
			  <li>Penyelenggara menayangkan penawaran efek Penerbit di Portal Penyelenggara</li>
			  <li>Pemodal tertarik untuk membeli saham milik Penerbit</li>
			  <li>Penyelenggara menerbitkan invoice perintah bayar kepada Pemodal</li>
			  <li>Pemodal membayar saham yang dibeli ke rekening escrow milik penyelenggara</li>
			  <li>Jika sudah terpenuhi jumlah dan waktunya, maka pihak penyelenggara mentransfer nilai pendanaan saham kepada penerbit</li>
			  <li>Penerbit menyerahkan sertifikat saham kepada Penyelenggara dan Kustodian</li>
			  <li>Kustodian menyerahkan sertifikasi saham kepada Pemodal</li>
			  <li>Jika sudah menjalankan bisnisnya dan menghasilkan profit, Penerbit memberikan dividen kepada Penyelenggara</li>
			  <li>Penyelenggara mentransfer dividen yang berasal dari penerbit kepada Pemodal</li>
			  </ol>
            </div>
          </div>
          <div class="col-md-12 col-lg-6 mb-4 mb-lg-0 border-right">
            <div class="text-center">
              <img src="<?php echo base_url(); ?>assetsprofile/assetsbaru/images/alur.png" width="70%" style="margin-top:6%;margin-bottom:6%;">
            </div>
          </div>
        </div>