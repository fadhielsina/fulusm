 <footer class="site-footer" style="border-radius: 80px 80px 0px 0px;">
      <div class="container">
        

        <div class="row">
          <div class="col-md-4">
          <img src="<?php echo base_url(); ?>assetsprofile/assetsbaru/images/dealfintech.jpg" width="60px" align="left" style="margin-right:10px;border-radius:40%">
		  <h4 class="font-weight-bold" style="color:#ddbc76;">FULUSME</h4>
		  <p>LAYANAN URUN DANA</p>
		  <br/>
            <h3 class="footer-heading mb-4 font-weight-bold" style="color:#ddbc76;" >Alamat</h3>
			<span style="font-weight:400;font-size:13px;">
                PT. Fintek Andalan Solusi Teknologi
                <br>
                Jl. Bendungan Hilir IV No.6
                Kecamatan Tanah Abang
                Jakarta Pusat,10210
                Indonesia 
                </span>
          </div>
          <div class="col-md-8">
            <div class="row">
              <div class="col-md-7">
               <h3 class="footer-heading mb-4 font-weight-bold" style="color:#ddbc76;">Hubungi Kami</h3>
			   <span style="font-weight:400;font-size:13px;">
                  Phone: +62 21 2520-934<br/>
                  Penerbit: +62 21 2555-8986<br/>
                  Pemodal: +62 21 2555-8986<br/>
                 UKM: +62 21 2555-8986<br/>
                  E-mail : <a href = "mailto: info@fulusme.id" target="_blank">info@fulusme.id</a> <br/>
                  WA : <a href="https://api.whatsapp.com/send?phone=6282299996862" target="_blank">+62 822 9999 6862</a> <br/>
                  Instagram : <a href="https://instagram.com/fulusme" target="_blank">@fulusme</a>
				 </span>
              </div>
              <div class="col-md-5">
                 <h3 class="footer-heading mb-4 font-weight-bold" style="color:#ddbc76;">Berizin dan diawasi oleh :</h3>
				  <img src="<?php echo base_url(); ?>assetsprofile/assetsbaru/images/ojk_footer_new.png" width="260px" align="left" style="margin-right:10px;">
              </div>
            </div>
          </div>

        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy; <script>document.write(new Date().getFullYear());</script> All Rights Reserved | FULUSME.ID
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/jquery-3.3.1.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/jquery-ui.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/popper.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/owl.carousel.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/jquery.stellar.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/jquery.countdown.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/jquery.magnific-popup.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/bootstrap-datepicker.min.js"></script>
  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/aos.js"></script>

  <script src="<?php echo base_url(); ?>assetsprofile/assetsbaru/js/main.js"></script>

  </body>
</html>