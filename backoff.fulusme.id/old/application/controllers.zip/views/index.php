 <?php $this->load->view('template/header'); ?>
   <?php $this->load->view('template/nav'); ?>    
  <?php $this->load->view('template/sidemenu'); ?>     
  <?php $this->load->view($main_content); ?>
 <?php $this->load->view('template/footer'); ?>     

