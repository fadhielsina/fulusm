<?php $this->load->view('layout/header'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('layout/footer'); ?>
