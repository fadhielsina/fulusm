 <?php echo $this->load->view("template/header"); ?>
   <!-- Main Wrapper -->
 	<?php echo $this->load->view($main_content); ?>
