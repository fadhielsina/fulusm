 <?php  $this->load->view("template/header"); ?>
 <?php  $this->load->view("template/topnav_admin"); ?>
 <?php  $this->load->view("template/sidebaradmin"); ?> 

<div class="page-wrapper">
	<div class="container-fluid">
		<?php if( 'home' != $this->uri->segment(1) && ! is_null( $this->uri->segment(1) ) ): ?>
		<div class="row page-titles">
            <div class="col-md-12 col-12 align-self-center">
                <?php if($this->uri->segment(1) == 'data_peminjam' || $this->uri->segment(1) == 'data_pendana') : ?>
                <?php if($this->uri->segment(1) == 'data_peminjam') : ?>
                <h3 class="text-themecolor mb-0 mt-0">Data Penerbit</h3>
                <?php else : ?>
                <h3 class="text-themecolor mb-0 mt-0">Data Pemodal</h3>
                <?php endif; ?>
                <?php else : ?>
                <h3 class="text-themecolor mb-0 mt-0"><?php echo $this->uri->segment(1); ?></h3>
                <?php endif; ?>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo site_url(); ?>">Home</a></li>
                    <?php if($this->uri->segment(1) == 'data_peminjam' || $this->uri->segment(1) == 'data_pendana') : ?>
                        <?php if($this->uri->segment(1) == 'data_peminjam') : ?>
                            <li class="breadcrumb-item active">Data Penerbit</li>
                        <?php else : ?>
                            <li class="breadcrumb-item active">Data Pemodal</li>
                        <?php endif; ?>
                <?php else : ?>
                    <li class="breadcrumb-item active"><?php echo $this->uri->segment(1); ?></li>
                <?php endif; ?>
                    <?php if( $this->uri->segment(2) ): ?>
                    <li class="breadcrumb-item active"><?php echo $this->uri->segment(2); ?></li>
                	<?php endif; ?>
                </ol>
            </div>
        </div>
    	<?php endif; ?>

    	<div id="alert_container">
    	<?php
    	if($this->session->flashdata('message') !="")
		{
			echo '
			<div class="alert alert-info">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
			<h5 class="text-info"><i class="fa fa-exclamation-circle"></i>Notifikasi :</h5> '.$this->session->flashdata('message').'
			</div>
			';
		}
		?>
		</div>

		<?php $this->load->view($main_content); ?>
	 </div>
 </div>

 <?php  $this->load->view("template/footer_admin"); ?>