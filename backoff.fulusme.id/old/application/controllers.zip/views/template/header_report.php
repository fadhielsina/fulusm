
<table style="width:100%;text-align:center;border-collapse: separate;border-spacing: 15px 4px;">
<tr><td><img src="<?php echo site_url(); ?>assets/img/logo_katingan.jpg" width="50"></td>
<td>
<h5 align="center" style="margin:0;color:#000;">PEMERINTAH KABUPATEN KATINGAN</h5>
<h5 align="center" style="margin:0;color:#000;">BADAN LAYANAN UMUM DAERAH</h5>
<h4 align="center" style="margin:0;color:#000;">RSUD MAS AMSYAR KASONGAN</h4>
<p align="center" style="margin:0;font-size:10px;color:#000;"><i>Jalan Tjilik Riwut Kasongan - Telp/Fax (0536) 404104</i></p>
<p align="center" style="margin:0;font-size:10px;color:#000;">E-mail: rsud@katingankab.go.id website: http://rsud.katingankab.go.id</p>
<p align="center" style="margin:0;font-size:10px;color:#000;"><strong>KASONGAN 74412</strong></p>
</td><td style="text-align:right;">
<img src="<?php echo site_url(); ?>assets/img/logo_rsud_katingan2.jpeg" width="80">
</td></tr></table><hr>